const database = {
    students: [
        { id: 1, name: "Alice", major: "CS" },
        { id: 2, name: "Bob", major: "IT" },
        { id: 3, name: "Charlie", major: "Cybersecurity" }
    ]
};

function runQuery() {
    const query = document.getElementById('query').value.trim().toUpperCase();
    let result = '';

    if (query === 'SELECT * FROM STUDENTS') {
        result = JSON.stringify(database.students, null, 2);
    } else {
        result = "Invalid or unsupported query.";
    }

    document.getElementById('result').textContent = result;
}